#!/usr/bin/env python3
"""Command-line interface for the AI Resume Analyzer.

Usage:
    python cli.py --resume path/to/resume.pdf --jd path/to/job_description.txt
    python cli.py --resume resume.docx --jd jd.txt --html report.html
    python cli.py --resume resume.txt --jd jd.txt --llm openai
"""

import argparse
import sys

from resume_analyzer import ResumeAnalyzer


def main():
    parser = argparse.ArgumentParser(description="AI Resume Analyzer")
    parser.add_argument("--resume", required=True, help="Path to resume (.pdf, .docx, .txt)")
    parser.add_argument("--jd", required=True, help="Path to job description (.pdf, .docx, .txt)")
    parser.add_argument("--html", help="Optional path to write an HTML report")
    parser.add_argument(
        "--llm", default="auto", choices=["auto", "openai", "huggingface", "none"],
        help="LLM backend for personalized suggestions (default: auto-detect from env vars)"
    )
    parser.add_argument(
        "--embeddings", action="store_true",
        help="Use sentence-transformer embeddings instead of TF-IDF for similarity (needs internet)"
    )
    args = parser.parse_args()

    analyzer = ResumeAnalyzer(use_embeddings=args.embeddings, llm_provider=args.llm)

    try:
        result = analyzer.analyze(resume_path=args.resume, jd_path=args.jd)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(analyzer.to_text(result))

    if args.html:
        with open(args.html, "w", encoding="utf-8") as f:
            f.write(analyzer.to_html(result))
        print(f"\nHTML report written to: {args.html}")


if __name__ == "__main__":
    main()

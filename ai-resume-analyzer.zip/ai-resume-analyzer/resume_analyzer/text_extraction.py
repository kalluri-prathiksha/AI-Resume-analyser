"""Extract raw text from resumes / job descriptions in various formats."""

from pathlib import Path


def extract_text(filepath: str) -> str:
    """Extract plain text from a .pdf, .docx, or .txt file.

    Args:
        filepath: path to the source file.

    Returns:
        Extracted text as a single string.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    suffix = path.suffix.lower()

    if suffix == ".pdf":
        return _extract_pdf(path)
    if suffix == ".docx":
        return _extract_docx(path)
    if suffix in (".txt", ".md"):
        return path.read_text(encoding="utf-8", errors="ignore")

    raise ValueError(
        f"Unsupported file type '{suffix}'. Supported: .pdf, .docx, .txt, .md"
    )


def _extract_pdf(path: Path) -> str:
    import pdfplumber

    text_parts = []
    with pdfplumber.open(str(path)) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_parts.append(page_text)
    return "\n".join(text_parts)


def _extract_docx(path: Path) -> str:
    import docx

    document = docx.Document(str(path))
    paragraphs = [p.text for p in document.paragraphs]

    # Also pull text out of any tables (skills tables etc.)
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text:
                    paragraphs.append(cell.text)

    return "\n".join(paragraphs)
